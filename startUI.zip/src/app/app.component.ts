import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'startUI';
  // playVideo = document.getElementById('play');


  playPause() {
    var myVideo: any = document.getElementById("play");
    if (myVideo.paused) myVideo.play();
    else myVideo.pause();
  }
}
